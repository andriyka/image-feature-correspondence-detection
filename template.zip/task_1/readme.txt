Task 1: Detection

hessian_response.m, 
hessian.m, 
harris_response.m, 
harris.m, 
nonmaxsup2d.m, (function provided) 
scalespace.m, 
nonmaxsup3d.m, (function provided) 
sshessian_response.m,
sshessian.m,