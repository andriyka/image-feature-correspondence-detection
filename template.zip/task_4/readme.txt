Task 4: Connecting the pipeline

your input images: obj%d_view%d.jpg, 
detections and descriptors: obj%d_view%d.mat, 
tentative correspondences: obj%d_tc.mat,
final results: obj%d_results.mat

