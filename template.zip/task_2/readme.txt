Task 2: Description

transnorm.m, 
simnorm.m, 
affnorm.m, 
photonorm.m,  (function provided)
dom_orientation.m,
dctdesc.m     (function provided)

