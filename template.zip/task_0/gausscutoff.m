function x=gausscutoff(sigma)
   x=[-ceil(3.0*sigma):ceil(3.0*sigma)];