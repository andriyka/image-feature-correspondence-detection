Task 0: Introduction

gauss.m
dgauss.m 
gaussfilter.m
gaussderiv.m
gaussderiv2.m
affine.m
affinetr.m 

(all functions are provided)

